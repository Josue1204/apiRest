INSERT INTO clientes(nombre,apellido,email,create_at)VALUES('Jonh','Vliside','jonh@gmail.com','2018-03-06');
INSERT INTO clientes(nombre,apellido,email,create_at)VALUES('Juan','Carranza','jua@gmail.com','2019-06-08');
INSERT INTO clientes(nombre,apellido,email,create_at)VALUES('Miguel','Perez','miguel@gmail.com','2020-05-01');
INSERT INTO clientes(nombre,apellido,email,create_at)VALUES('Diego','Carrio','diego@gmail.com','2021-04-12');